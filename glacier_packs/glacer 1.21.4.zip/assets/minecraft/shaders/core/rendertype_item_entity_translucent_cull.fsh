
#version 150

#moj_import <minecraft:fog.glsl>

uniform sampler2D Sampler0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

flat in vec4 borderColor;
in vec3 borderSlotA;
in vec3 borderSlotC;
in vec4 borderUv;
in vec3 borderClip;
in vec3 borderRay;

out vec4 fragColor;

const float PI = 3.14159265359;
const float TWO_PI = 6.28318530718;
const float BASE_Y = 65536.0;
const float TILE_PIXELS = 16.0;
const float MAX_FOOTPRINT = 2.0;
const float FADE_START = 192.0;
const float FADE_END = 320.0;

bool borderFragment(bool farLayer, out vec4 color, out float deviceDepth) {
    float weightB = (borderClip.x + 4.0) / 16.0;
    float weightC = (borderClip.y + 4.0) / 16.0;
    float weightA = 1.0 - weightB - weightC;
    vec3 cornerA = borderSlotA / weightA;
    vec3 cornerC = borderSlotC / weightC;
    vec2 center = (cornerA.xz + cornerC.xz) * 0.5;
    float radius = (abs(cornerC.x - cornerA.x) + abs(cornerC.z - cornerA.z)) * 0.25;
    float cameraY = BASE_Y + (farLayer ? 1.0 : 0.0) - (cornerA.y + cornerC.y) * 0.5;

    vec3 dir = normalize(borderRay);
    float len = length(center);
    float a = max(dot(dir.xz, dir.xz), 0.000001);
    float b = -dot(center, dir.xz);
    float c = (len - radius) * (len + radius);
    float disc = b * b - a * c;
    float root = sqrt(max(disc, 0.0));
    float tNear = -(b + root) / a;
    float tFar = (root - b) / a;
    bool inside = c < 0.0;
    float t = (farLayer || inside) ? tFar : tNear;
    bool hit = disc > 0.0 && t > 0.0 && radius > 0.0 && (!farLayer || (!inside && tNear > 0.0));

    vec3 pos = t * dir;
    vec2 away = -center;
    vec2 ring = away + pos.xz;
    float cameraAngle = atan(away.y, away.x);
    float delta = atan(away.x * pos.z - away.y * pos.x, dot(away, ring));
    float wrap = floor((cameraAngle + delta + PI) / TWO_PI);
    float arc = radius * 0.5;
    float worldY = pos.y + cameraY;
    vec2 tile = vec2(fract(arc * cameraAngle) + arc * (delta - TWO_PI * wrap), -worldY * 0.5) + fract(GameTime * 400.0);

    vec2 tangent = normalize(vec2(-ring.y, ring.x));
    vec2 gradX = vec2(dot(dFdx(pos.xz), tangent), -dFdx(pos.y)) * 0.5;
    vec2 gradY = vec2(dot(dFdy(pos.xz), tangent), -dFdy(pos.y)) * 0.5;
    float footprint = max(length(gradX), length(gradY)) * TILE_PIXELS;
    float limit = min(1.0, MAX_FOOTPRINT / max(footprint, 0.000001));
    gradX *= limit;
    gradY *= limit;

    vec2 atlas = vec2(textureSize(Sampler0, 0));
    vec2 spriteSize = TILE_PIXELS / atlas;
    vec2 origin = floor((borderUv.xy / weightA + borderUv.zw / weightC) * 0.5 * atlas + 0.5) / atlas;
    vec2 inner = clamp(fract(tile), vec2(0.5 / TILE_PIXELS), vec2(1.0 - 0.5 / TILE_PIXELS));
    vec4 texel = textureGrad(Sampler0, origin + inner * spriteSize, gradX * spriteSize, gradY * spriteSize);

    float fade = 1.0 - smoothstep(FADE_START, FADE_END, t);
    color = vec4(texel.rgb * borderColor.rgb, texel.a * fade) * ColorModulator;

    vec4 clip = ProjMat * (ModelViewMat * vec4(pos, 1.0));
    float ndc = clip.z / clip.w;
    float ratio = dFdy(gl_FragCoord.z) / dFdy(borderClip.z);
    float slope = (ratio < 0.0 ? -1.0 : 1.0) * (abs(ratio) > 0.75 ? 1.0 : 0.5);
    deviceDepth = gl_FragCoord.z + slope * (ndc - borderClip.z);

    return hit && color.a >= 0.01;
}

void main() {
    gl_FragDepth = gl_FragCoord.z;

    if (borderColor.a > 0.5) {
        vec4 borderResult;
        float borderDepth;
        if (!borderFragment(borderColor.a > 1.5, borderResult, borderDepth)) {
            discard;
        }
        gl_FragDepth = borderDepth;
        fragColor = borderResult;
        return;
    }

    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
