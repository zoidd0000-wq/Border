
#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

flat out vec4 borderColor;
out vec3 borderSlotA;
out vec3 borderSlotC;
out vec4 borderUv;
out vec3 borderClip;
out vec3 borderRay;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;

    borderColor = vec4(0.0);
    borderSlotA = vec3(0.0);
    borderSlotC = vec3(0.0);
    borderUv = vec4(0.0);
    borderClip = vec3(0.0);
    borderRay = vec3(0.0);

    if (max(abs(UV0.x - 0.5), abs(UV0.y - 0.5)) > 2.0) {
        bool farLayer = (int(Color.b * 255.0 + 0.5) & 1) == 1;
        vec2 sgn = vec2(UV0.x > 0.5 ? 1.0 : -1.0, UV0.y > 0.5 ? 1.0 : -1.0);
        bool diagonal = sgn.x == sgn.y;
        bool typeA = diagonal && sgn.x < 0.0;
        bool typeC = diagonal && sgn.x > 0.0;
        vec2 corner = typeA ? vec2(-4.0, -4.0) : (typeC ? vec2(-4.0, 12.0) : vec2(12.0, -4.0));
        float cornerZ = typeA ? 0.2 : (typeC ? 0.8 : 0.5);

        mat4 invProj = inverse(ProjMat);
        vec4 nearPoint = invProj * vec4(corner, 0.25, 1.0);
        vec4 farPoint = invProj * vec4(corner, 0.75, 1.0);
        vec3 viewDir = farPoint.xyz / farPoint.w - nearPoint.xyz / nearPoint.w;
        viewDir = (ProjMat * vec4(viewDir, 0.0)).w < 0.0 ? -viewDir : viewDir;

        gl_Position = vec4(corner, cornerZ, 1.0);
        borderClip = vec3(corner, cornerZ);
        borderColor = vec4(Color.rgb, farLayer ? 2.0 : 1.0);
        borderSlotA = typeA ? Position : vec3(0.0);
        borderSlotC = typeC ? Position : vec3(0.0);
        borderUv = typeA ? vec4(UV0, 0.0, 0.0) : (typeC ? vec4(0.0, 0.0, UV0) : vec4(0.0));
        borderRay = inverse(mat3(ModelViewMat)) * viewDir;
    }
}
