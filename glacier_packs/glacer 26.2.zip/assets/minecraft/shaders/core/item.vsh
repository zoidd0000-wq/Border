#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
flat out vec4 borderData;
flat out vec4 borderUv;
flat out vec4 borderColor;
out vec3 borderRay;
out float borderZ;

const float BORDER_MARKER_Y = 61440.0;
const float BORDER_BASE_Y = 65536.0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;

    borderData = vec4(0.0);
    borderUv = vec4(0.0);
    borderColor = vec4(0.0);
    borderRay = vec3(0.0);
    borderZ = 0.0;

    float worldY = Position.y + float(CameraBlockPos.y) + abs(CameraOffset.y);
    if (worldY > BORDER_MARKER_Y) {
        bool farLayer = (int(Color.b * 255.0 + 0.5) & 1) == 1;
        vec2 sgn = vec2(UV0.x > 0.5 ? 1.0 : -1.0, UV0.y > 0.5 ? 1.0 : -1.0);
        vec2 corner = sgn.x == sgn.y ? (sgn.x < 0.0 ? vec2(-1.0, -1.0) : vec2(-1.0, 5.0)) : vec2(5.0, -1.0);
        float cornerZ = sgn.x == sgn.y ? (sgn.x < 0.0 ? 0.2 : 0.8) : 0.5;

        mat4 invProj = inverse(ProjMat);
        vec4 near = invProj * vec4(corner, 0.25, 1.0);
        vec4 far = invProj * vec4(corner, 0.75, 1.0);
        vec3 viewDir = far.xyz / far.w - near.xyz / near.w;
        viewDir = (ProjMat * vec4(viewDir, 0.0)).w < 0.0 ? -viewDir : viewDir;

        gl_Position = vec4(corner, cornerZ, 1.0);
        borderZ = cornerZ;
        borderData = vec4(Position.x, Position.z, worldY - BORDER_BASE_Y - (farLayer ? 1.0 : 0.0), farLayer ? 2.0 : 1.0);
        borderUv = vec4(UV0, sgn);
        borderColor = Color;
        borderRay = inverse(mat3(ModelViewMat)) * viewDir;
    }
}