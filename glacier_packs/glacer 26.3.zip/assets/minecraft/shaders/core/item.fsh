#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif
layout(location = 7) flat in vec4 borderData;
layout(location = 8) flat in vec4 borderUv;
layout(location = 9) flat in vec4 borderColor;
layout(location = 10) in vec3 borderRay;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

const float PI = 3.14159265359;
const float TWO_PI = 6.28318530718;
const float TILE_PIXELS = 16.0;
const float UV_RANGE = 4096.0;
const float MAX_FOOTPRINT = 2.0;
const float FADE_START = 192.0;
const float FADE_END = 320.0;


bool borderFragment(bool farLayer, out vec4 color, out float deviceDepth) {
    vec3 dir = normalize(borderRay);
    vec2 center = borderData.xy;
    float radius = borderData.z;
    float len = length(center);
    float a = max(dot(dir.xz, dir.xz), 0.000001);
    float b = -dot(center, dir.xz);
    float c = (len - radius) * (len + radius);
    float disc = b * b - a * c;
    float root = sqrt(max(disc, 0.0));
    float tNear = -(b + root) / a;
    float tFar = (root - b) / a;
    bool inside = c < 0.0;
    float t = (farLayer || inside) ? tFar : tNear;
    bool hit = disc > 0.0 && t > 0.0 && radius > 0.0 && (!farLayer || (!inside && tNear > 0.0));

    vec3 pos = t * dir;
    vec2 away = -center;
    vec2 ring = away + pos.xz;
    float cameraAngle = atan(away.y, away.x);
    float delta = atan(away.x * pos.z - away.y * pos.x, dot(away, ring));
    float wrap = floor((cameraAngle + delta + PI) / TWO_PI);
    float arc = radius * 0.5;
    float worldY = pos.y + float(CameraBlockPos.y) - CameraOffset.y;
    vec2 tile = vec2(fract(arc * cameraAngle) + arc * (delta - TWO_PI * wrap), -worldY * 0.5) + fract(GameTime * 400.0);

    vec2 tangent = normalize(vec2(-ring.y, ring.x));
    vec2 gradX = vec2(dot(dFdx(pos.xz), tangent), -dFdx(pos.y)) * 0.5;
    vec2 gradY = vec2(dot(dFdy(pos.xz), tangent), -dFdy(pos.y)) * 0.5;
    float footprint = max(length(gradX), length(gradY)) * TILE_PIXELS;
    float limit = min(1.0, MAX_FOOTPRINT / max(footprint, 0.000001));
    gradX *= limit;
    gradY *= limit;

    vec2 atlas = vec2(textureSize(Sampler0, 0));
    vec2 spriteSize = TILE_PIXELS / atlas;
    vec2 origin = floor((borderUv.xy - borderUv.zw * UV_RANGE * spriteSize) * atlas + 0.5) / atlas;
    vec2 inner = clamp(fract(tile), vec2(0.5 / TILE_PIXELS), vec2(1.0 - 0.5 / TILE_PIXELS));
    vec4 texel = textureGrad(Sampler0, origin + inner * spriteSize, gradX * spriteSize, gradY * spriteSize);

    float fade = 1.0 - smoothstep(FADE_START, FADE_END, t);
    color = vec4(texel.rgb * borderColor.rgb, texel.a * fade) * ColorModulator;

    vec4 clip = ProjMat * (ModelViewMat * vec4(pos, 1.0));
    float ndc = clip.z / clip.w;
    #ifdef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
    deviceDepth = ndc;
    #else
    deviceDepth = ndc * 0.5 + 0.5;
    #endif

    return hit && color.a >= 0.01;
}
#ifdef OIT_TRANSMITTANCE
void addTransmittanceAt(float transmittance, float deviceDepth) {
    float coefficients[OIT_COEFF_COUNT];
    for (int i = 0; i < OIT_COEFF_COUNT; i++) {
        coefficients[i] = 0;
    }

    float absorbance = toAbsorbance(transmittance);

    float originalDepth = normalizeDepth(deviceDepth);
    float depth = originalDepth * float(OIT_NUMBER_OF_DEPTH_BINS - 1) / OIT_NUMBER_OF_DEPTH_BINS;

    float averageAbsorbance = absorbance * (1 - depth);
    coefficients[0] = averageAbsorbance;

    int depthBinIndex = int(floor(originalDepth * (OIT_NUMBER_OF_DEPTH_BINS - 1)));
    int treeIndex = depthBinIndex + OIT_COEFF_COUNT;

    for (int waveletLevel = 0; waveletLevel <= OIT_WAVELET_RANK; waveletLevel++) {
        int power = OIT_WAVELET_RANK - waveletLevel;
        int parentIndex = treeIndex >> 1;
        float indexAtParentLevel = float(parentIndex & ((1 << power) - 1));

        int isRightHalf = treeIndex & 1;
        int waveletSign = 1 - (isRightHalf << 1);
        float waveletWidth = exp2(-power);
        float waveletHeightScale = exp2(power * 0.5);
        float depthOffsetRelativeToWavelet = depth - waveletWidth * indexAtParentLevel;
        float distanceFromWaveletEdge = isRightHalf * waveletWidth + waveletSign * depthOffsetRelativeToWavelet;
        float differenceCoefficient = distanceFromWaveletEdge * waveletHeightScale * absorbance;
        coefficients[parentIndex] = differenceCoefficient;

        treeIndex = parentIndex;
    }

    for (int attachmentIndex = 0; attachmentIndex < OIT_COEFF_ATTACHMENT_COUNT; attachmentIndex++) {
        for (int i = 0; i < 4; i++) {
            coeff[attachmentIndex][i] = coefficients[attachmentIndex * 4 + i];
        }
    }
}
#endif

#ifdef OIT_ACCUMULATE
vec4 accumulateAt(vec4 color, float deviceDepth) {
    float sampledTransmittance = sampleTransmittance(ivec2(gl_FragCoord.xy), normalizeDepth(deviceDepth), 1.0 - color.a);
    return vec4(color.rgb * color.a, color.a) * sampledTransmittance;
}
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

void main() {
    gl_FragDepth = gl_FragCoord.z;

    if (borderData.w > 0.5) {
        vec4 borderResult;
        float borderDepth;
        if (!borderFragment(borderData.w > 1.5, borderResult, borderDepth)) {
            discard;
        }
        gl_FragDepth = borderDepth;
        #ifdef OIT_ALPHA_ONLY
        #ifdef OIT_TRANSMITTANCE
        addTransmittanceAt(1.0 - borderResult.a, borderDepth);
        #else
        executeAlphaOnlyPhase(borderDepth, borderResult.a);
        #endif
        #elif defined(OIT_ACCUMULATE)
        fragColor = accumulateAt(borderResult, borderDepth);
        #else
        fragColor = borderResult;
        #endif
        return;
    }

    vec4 color = texture(Sampler0, texCoord0);
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}