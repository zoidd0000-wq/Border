#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif
layout(location = 7) flat out vec4 borderData;
layout(location = 8) flat out vec4 borderUv;
layout(location = 9) flat out vec4 borderColor;
layout(location = 10) out vec3 borderRay;

const float BORDER_MARKER_Y = 61440.0;
const float BORDER_BASE_Y = 65536.0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif

    borderData = vec4(0.0);
    borderUv = vec4(0.0);
    borderColor = vec4(0.0);
    borderRay = vec3(0.0);

    float worldY = Position.y + float(CameraBlockPos.y) - CameraOffset.y;
     if (worldY > BORDER_MARKER_Y) {
        bool farLayer = (int(Color.b * 255.0 + 0.5) & 1) == 1;
        vec2 sgn = vec2(UV0.x > 0.5 ? 1.0 : -1.0, UV0.y > 0.5 ? 1.0 : -1.0);
        vec2 corner = sgn.x == sgn.y ? (sgn.x < 0.0 ? vec2(-1.0, -1.0) : vec2(-1.0, 5.0)) : vec2(5.0, -1.0);

        mat4 invProj = inverse(ProjMat);
        vec4 near = invProj * vec4(corner, 0.25, 1.0);
        vec4 far = invProj * vec4(corner, 0.75, 1.0);
        vec3 viewDir = far.xyz / far.w - near.xyz / near.w;
        viewDir = (ProjMat * vec4(viewDir, 0.0)).w < 0.0 ? -viewDir : viewDir;

        gl_Position = vec4(corner, 0.5, 1.0);
        borderData = vec4(Position.x, Position.z, worldY - BORDER_BASE_Y - (farLayer ? 1.0 : 0.0), farLayer ? 2.0 : 1.0);
        borderUv = vec4(UV0, sgn);
        borderColor = Color;
        borderRay = inverse(mat3(ModelViewMat)) * viewDir;
    }
}